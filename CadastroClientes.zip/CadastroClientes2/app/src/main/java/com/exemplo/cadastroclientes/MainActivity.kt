package com.exemplo.cadastroclientes

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.regex.Pattern

class MainActivity : AppCompatActivity() {

    // Declaração das variáveis para os componentes de UI
    private lateinit var nameEditText: TextInputEditText
    private lateinit var emailEditText: TextInputEditText
    private lateinit var genderRadioGroup: RadioGroup
    private lateinit var educationDropdown: AutoCompleteTextView
    private lateinit var submitButton: MaterialButton
    private lateinit var successLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicialização dos componentes de UI
        nameEditText = findViewById(R.id.editTextName)
        emailEditText = findViewById(R.id.editTextEmail)
        genderRadioGroup = findViewById(R.id.radioGroupGender)
        educationDropdown = findViewById(R.id.dropdownEducation)
        submitButton = findViewById(R.id.buttonSubmit)
        successLayout = findViewById(R.id.layoutSuccess)

        // Configuração do dropdown de escolaridade
        setupEducationDropdown()

        // Configuração do botão de envio
        submitButton.setOnClickListener {
            if (validateForm()) {
                submitForm()
            }
        }
    }

    private fun setupEducationDropdown() {
        val educationOptions = arrayOf(
            "Ensino Fundamental",
            "Ensino Médio",
            "Ensino Superior",
            "Pós-graduação",
            "Mestrado",
            "Doutorado"
        )

        val adapter = ArrayAdapter(
            this,
            R.layout.dropdown_item,
            educationOptions
        )

        educationDropdown.setAdapter(adapter)
    }

    private fun validateForm(): Boolean {
        var isValid = true

        // Validação do nome
        val name = nameEditText.text.toString().trim()
        if (name.length < 3) {
            nameEditText.error = "Nome deve ter pelo menos 3 caracteres"
            isValid = false
        }

        // Validação do email
        val email = emailEditText.text.toString().trim()
        val emailPattern = Pattern.compile(
            "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
        )

        if (!emailPattern.matcher(email).matches()) {
            emailEditText.error = "Formato de email inválido"
            isValid = false
        }

        // Validação do sexo
        if (genderRadioGroup.checkedRadioButtonId == -1) {
            Toast.makeText(
                this,
                "Selecione uma opção para Sexo",
                Toast.LENGTH_SHORT
            ).show()
            isValid = false
        }

        // Validação da escolaridade
        if (educationDropdown.text.toString().isEmpty()) {
            educationDropdown.error = "Selecione sua escolaridade"
            isValid = false
        }

        return isValid
    }

    private fun submitForm() {
        // Recuperação dos dados do formulário
        val name = nameEditText.text.toString().trim()
        val email = emailEditText.text.toString().trim()
        val genderRadioButtonId = genderRadioGroup.checkedRadioButtonId

        val gender = when (genderRadioButtonId) {
            R.id.radioMale -> "Masculino"
            R.id.radioFemale -> "Feminino"
            else -> "Outro"
        }

        val education = educationDropdown.text.toString()

        // Criação do objeto Cliente com os dados do formulário
        val client = Client(name, email, gender, education)

        // Aqui você implementaria o código para enviar os dados
        // para uma API ou salvar localmente
        // Por exemplo:
        // saveClientLocally(client)
        // ou
        // sendClientToApi(client)

        // Exibição da mensagem de sucesso
        showSuccessMessage()
    }

    private fun showSuccessMessage() {
        // Mostrar a mensagem de sucesso
        successLayout.visibility = View.VISIBLE

        // Esconder a mensagem após 3 segundos e limpar o formulário
        Handler(Looper.getMainLooper()).postDelayed({
            successLayout.visibility = View.GONE

            // Limpar o formulário
            nameEditText.setText("")
            emailEditText.setText("")
            genderRadioGroup.clearCheck()
            educationDropdown.setText("")

            // Limpar o foco
            nameEditText.clearFocus()
            emailEditText.clearFocus()
            educationDropdown.clearFocus()
        }, 3000)
    }

    // Classe de dados para representar um Cliente
    data class Client(
        val name: String,
        val email: String,
        val gender: String,
        val education: String,
        val createdAt: String = System.currentTimeMillis().toString()
    )
}